var testingAngluarApp = angular.module('testingAngularApp', []);

testingAngluarApp.controller('testingAngularCtrl', function ($rootScope, $scope) {

    $scope.title = "Testing AngularJS Applications";

});
